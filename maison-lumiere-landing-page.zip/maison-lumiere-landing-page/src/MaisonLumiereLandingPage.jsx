export default function MaisonLumiereLandingPage() {
  return <div>Maison Lumière Landing Page</div>;
}
